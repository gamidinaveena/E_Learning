package Testcases;

import org.testng.annotations.Test;


public class Elearnng {

	@Test
  public void f() 
  {
		Launch  f=new Launch();
		ExcelOp op=new ExcelOp();
//		String str=op.operations(0, 0);
//		String str1=op.operations(0, 1);
//		f.login(str, str1);
//		String str2=op.operations(1, 0);
//		String str3=op.operations(1, 1);
//		String str4=op.operations(1, 2);
//		f.coursecreate(str2, str3, str4);
//		
				
		
  }
}
